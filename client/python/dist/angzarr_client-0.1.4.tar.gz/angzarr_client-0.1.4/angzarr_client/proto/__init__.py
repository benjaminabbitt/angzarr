"""Proto module for generated protobuf code."""
