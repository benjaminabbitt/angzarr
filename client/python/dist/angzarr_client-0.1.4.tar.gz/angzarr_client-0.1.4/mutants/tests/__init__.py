"""Tests for angzarr_client."""
